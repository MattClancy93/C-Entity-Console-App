using SWE5101_assignment_2_1707299;
using Microsoft.VisualStudio.TestTools.UnitTesting;



namespace Assignment_2_Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void customerTest()
        {
            Customer c = new Customer();
            c.displayCustomers();
        }
        [TestMethod]
        public void vehicleTest()
        {
            Vehicle c = new Vehicle();
            c.printVehicles();
        }
        [TestMethod]
        public void offsiteTest()
        {
            Offsite c = new Offsite();
            c.printVehicles();
        }
        [TestMethod]
        public void rentalTest()
        {
            Rental c = new Rental();
            c.printVehicles();
        }
    }
}
