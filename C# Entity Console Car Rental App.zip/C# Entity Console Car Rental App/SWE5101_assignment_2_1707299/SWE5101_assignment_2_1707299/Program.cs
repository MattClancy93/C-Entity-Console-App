﻿using System;

namespace SWE5101_assignment_2_1707299
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer c = new Customer();
            Vehicle v = new Vehicle();
            Rental r = new Rental();
            Offsite o = new Offsite();

            bool exit = false;
            while (exit == false)
            {
                Console.WriteLine("Please select an option:" +
                "\nA) Add a vehicle" +
                "\nB) Remove a vehicle" +
                "\nC) Adding a customer" +
                "\nD) Removing a customer" +
                "\nE) Record that a vehicle has been Sent for refuelling" +
                "\nF) Record that a vehicle has been Sent for repair" +
                "\nG) Record that a vehicle is back from refuel/repair" +
                "\nH) Display All Rentals/Search for rental customers" +
                "\nI) Add a Rental" +
                "\nJ) Remove a Rental");
                string choice = Console.ReadLine();

                switch (choice.ToLower())
                {
                    case "a":
                        Console.Clear();
                        v.AddAVehicle();
                        Console.Clear();
                        break;
                    case "b":
                        Console.Clear();
                        v.removeVehicle();
                        Console.Clear();
                        break;
                    case "c":
                        Console.Clear();
                        c.AddCustomer();
                        Console.Clear();
                        break;
                    case "d":
                        Console.Clear();
                        c.RemoveCustomer();
                        Console.Clear();
                        break;
                    case "e":
                        Console.Clear();
                        o.addRefuel();
                        Console.Clear();
                        break;
                    case "f":
                        Console.Clear();
                        o.addRepair();
                        Console.Clear();
                        break;
                    case "g":
                        Console.Clear();
                        o.returnVehicle();
                        Console.Clear();
                        break;
                    case "h":
                        Console.Clear();
                        r.displayRentals();
                        Console.Clear();
                        break;
                    case "i":
                        Console.Clear();
                        r.addRental();
                        Console.Clear();
                        break;
                    case "j":
                        Console.Clear();
                        r.returnVehicle();
                        Console.Clear();
                        break;
                }
            }



        }
    }
}
