﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading;

namespace SWE5101_assignment_2_1707299
{
    public class Rental : Vehicle
    {
        public Rental()
        {

        }

        Customer c = new Customer();

        DBScheme DBScheme1 = new DBScheme();

        public Rental(Vehicle v)
        {
            this.type = v.type;
            this.fuelType = v.fuelType;
            this.fuelStatus = v.fuelStatus;
            this.bodyType = v.bodyType;
            this.manufacturer = v.manufacturer;
            this.registrationPlate = v.registrationPlate;
            this.model = v.model;
            this.transmission = v.transmission;
            this.discriminator = "Rental";
        }

        public Rental(Vehicle v, int offsite)
        {
            this.type = v.type;
            this.fuelType = v.fuelType;
            this.fuelStatus = v.fuelStatus;
            this.bodyType = v.bodyType;
            this.manufacturer = v.manufacturer;
            this.registrationPlate = v.registrationPlate;
            this.model = v.model;
            this.transmission = v.transmission;
            this.discriminator = "Rental";
            this.offsite = offsite;
        }

        public void displayRentals()
        {
            var info = DBScheme1.Vehicles.ToList();
            var cust = DBScheme1.Customers.ToList();
            var count = 0;
            foreach (var x in cust)
            {
                if (x.rentalID > 0)
                {
                    var a = DBScheme1.Vehicles.Find(x.rentalID);
                    if(a != null)
                    {
                        Console.WriteLine("\n\nID: " + a.ID + "\nType: " + a.type + "\nFuel Type: " + a.fuelType + "\nFuel Status: " + a.fuelStatus + "\nBody Type: " + a.bodyType + "\nManufacturer: " + a.manufacturer + "\nRegistration Plate: " + a.registrationPlate + "\nModel: " + a.model + "\nTransmission: " + a.transmission);
                        count = 1;
                    }
                    else
                    {
                        count = 0;
                    }
                    
                }
                else
                {
                    continue;
                }
            }

            if(count == 1)
            {
                Console.WriteLine("\nThe following options are available: \nA - Show all customers and specify to view rentals. \nB - Show all rental customers.");
                var input = Console.ReadLine();
                if (input.ToLower() == "a")
                {
                    showRentalsByCustomer();
                }
                else if(input.ToLower() == "b")
                {
                    showAllCustomers();
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("ERROR");
                    Thread.Sleep(2000);
                }
            }
            else
            {
                Console.WriteLine("No Rentals found.");
                Console.WriteLine("Redirecting to Main Menu...");
                Thread.Sleep(2000);
            }

        }

        public void addRental()
        {
            var vcs = DBScheme1.Vehicles.ToList();
            Console.WriteLine("AVAILABLE VEHICLES");
            var vehicleCount= 0;
            foreach (var a in vcs)
            {
                if(a.offsite == 0)
                {
                    Console.WriteLine("\n\nID: " + a.ID + "\nType: " + a.type + "\nFuel Type: " + a.fuelType + "\nFuel Status: " + a.fuelStatus + "\nBody Type: " + a.bodyType + "\nManufacturer: " + a.manufacturer + "\nRegistration Plate: " + a.registrationPlate + "\nModel: " + a.model + "\nTransmission: " + a.transmission);
                    vehicleCount += 1;
                }
                else
                {
                    continue;
                }
                
            }
            if (vehicleCount <= 0)
            {
                Console.WriteLine("There are no current vehicles available. A rental cannot be made. Add more vehicles to create a rental.");
                Thread.Sleep(6000);
            }
            else
            {
                var info = DBScheme1.Customers.ToList();
                Console.WriteLine("\nAVAILABLE CUSTOMERS");
                var customerCount = 0;
                foreach (var a in info)
                {
                    if (a.rentalID.Equals(0))
                    {
                        Console.WriteLine("\nID: " + a.ID + "\nName: " + a.name + "\n");
                        customerCount += 1;
                    }
                    else
                    {
                        continue;
                    }

                }
                if (customerCount <= 0)
                {
                    Console.WriteLine("There are no current customers. A rental cannot be made. Add more customers to create a rental.");
                    Thread.Sleep(6000);
                }
                else
                {
                    Console.WriteLine("please enter ID of the vehicle you wish to rent: ");
                    int y = int.Parse(Console.ReadLine());
                    var x = DBScheme1.Vehicles.Find(y);

                    Rental r = new Rental(x, 2);

                    DBScheme1.Vehicles.Remove(x);
                    DBScheme1.Vehicles.Add(r);
                    DBScheme1.SaveChanges();

                    Console.WriteLine("Please enter ID of Customer: ");
                    int z = int.Parse(Console.ReadLine());
                    var name = DBScheme1.Customers.Find(z);

                    DBScheme1.Customers.Remove(name);

                    var vcs1 = DBScheme1.Vehicles.ToList();

                    var j = vcs1.Last();

                    Customer s = new Customer(name.name, j.ID);

                    DBScheme1.Customers.Add(s);
                    DBScheme1.SaveChanges();
                }
            }
            

            

        }

        public void showAllCustomers()
        {
            var info = DBScheme1.Vehicles.ToList();
            var cust = DBScheme1.Customers.ToList();
            Console.WriteLine("Current Rental Customers:");
            foreach (var x in cust)
            {
                if (x.rentalID > 0)
                {
                    var a = DBScheme1.Vehicles.Find(x.rentalID);
                    if (a != null)
                    {
                        Console.WriteLine("\nRental ID: " + x.rentalID + "\nName: " + x.name + "\n");
                    }
                    else
                    {
                        continue;
                    }

                }
                else
                {
                    continue;
                }
            }
        }
        public void returnVehicle()
        {
            var info = DBScheme1.Customers.ToList();
            var vcs = DBScheme1.Vehicles.ToList();
            var count = 0;

            foreach (var a in info)
            {
                if(a.rentalID > 0)
                {
                    Console.WriteLine("Customer ID: " + a.ID);
                    Console.WriteLine("Customer Name: " + a.name + "\n");
                    count += 1;
                }
                else
                {
                    continue;
                    
                }

            }
            if(count > 0)
            {
                Console.WriteLine("please enter CUSTOMER ID of the Rental you wish to remove: ");
                var y = Console.ReadLine();
                int z;
                if (int.TryParse(y, out z))
                {
                    var x = DBScheme1.Customers.Find(z);
                    if (x == null)
                    {
                        Console.WriteLine("Error, Please try again.");
                        returnVehicle();
                    }
                    else
                    {
                        int f = x.rentalID;
                        var b = DBScheme1.Vehicles.Find(f);
                        Vehicle v = new Vehicle(b.type, b.fuelType, b.fuelStatus, b.bodyType, b.manufacturer, b.registrationPlate, b.model, b.transmission, "Vehicle");
                        DBScheme1.Vehicles.Remove(b);
                        DBScheme1.Customers.Remove(x);
                        DBScheme1.Vehicles.Add(v);
                        DBScheme1.SaveChanges();
                    }
                }
                else
                {
                    Console.WriteLine("ERROR");
                    Thread.Sleep(1000);
                }
            }
            else
            {
                Console.WriteLine("No Rentals found.");
                Console.WriteLine("Redirecting to Main Menu...");
                Thread.Sleep(2000);
            }
            

        }

        public void showRentalsByCustomer() 
        {
            var info = DBScheme1.Customers.ToList();
            var vcs = DBScheme1.Vehicles.ToList();
            foreach (var a in info)
            {
                Console.WriteLine("\nCustomer ID: " + a.ID);
                Console.WriteLine("Customer Name: " + a.name);
            }

            Console.WriteLine("Enter Customer name to view customer: ");
            string c = Console.ReadLine();
            foreach (var x in info)
            {
                if (x.name.ToLower() == c.ToLower())
                {
                    var a = DBScheme1.Vehicles.Find(x.rentalID);
                    if(a == null)
                    {
                        Console.WriteLine(x.name + " has no rentals \n");
                        Thread.Sleep(2000);
                        showRentalsByCustomer();
                    }
                    Console.WriteLine(x.name + " " + x.rentalID + " " + a.type + " " + a.fuelType + " " + a.fuelStatus + " " + a.bodyType + " " + a.manufacturer + " " + a.registrationPlate + " " + a.model + " " + a.transmission);
                    Thread.Sleep(4000);
                }
                else
                {
                    continue;
                }
            }

        }
    }
}
