﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace SWE5101_assignment_2_1707299
{
    public class Customer
    {
        public int ID { get; set; }
        public string name { get; set; }

        public int rentalID { get; set; }

        public Customer()
        {

        }
        public Customer(string name)
        {
            this.name = name;
        }

        public Customer(string name, int rentalID)
        {
            this.name = name;
            this.rentalID = rentalID;
        }

        DBScheme DBScheme1 = new DBScheme();

        public void AddCustomer()
        {
            Console.WriteLine("Enter customer full name: ");
            Customer c = new Customer(Console.ReadLine());

            DBScheme1.Customers.Add(c);
            DBScheme1.SaveChanges();
        }

        public void displayCustomers()
        {
            var info = DBScheme1.Customers.ToList();
            foreach (var a in info)
            {
                if (a.rentalID.Equals(0))
                {
                    Console.WriteLine("\nID: " + a.ID + "\nName: " + a.name);
                }

            }
        }

        public void RemoveCustomer()
        {
            var info = DBScheme1.Customers.ToList();
            foreach (var a in info)
            {
                Console.WriteLine("\nID: " + a.ID + "\nName: " + a.name);
            }
            Console.WriteLine("Enter customer account number: ");
            var y = Console.ReadLine();
            int z;
            if (int.TryParse(y, out z))
            {
                var x = DBScheme1.Customers.Find(z);
                DBScheme1.Customers.Remove(x);
                DBScheme1.SaveChanges();
            }
            else
            {
                Console.WriteLine("ERROR");
                Thread.Sleep(1000);
            }
        }
    }
}
