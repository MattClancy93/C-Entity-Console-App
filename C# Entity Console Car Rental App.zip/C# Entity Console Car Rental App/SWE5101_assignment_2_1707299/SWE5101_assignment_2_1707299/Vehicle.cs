﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;

namespace SWE5101_assignment_2_1707299
{

    public class Vehicle
    {
        public int ID { get; set; }
        [NotMapped]
        public string discriminator { get; set; }
        public int offsite { get; set; }
        public string type { get; set; }
        public string fuelType { get; set; }
        public string fuelStatus { get; set; }
        public string bodyType { get; set; }
        public string manufacturer { get; set; }
        public string registrationPlate { get; set; }
        public string model { get; set; }
        public string transmission { get; set; }

        DBScheme DBScheme1 = new DBScheme();

        public Vehicle()
        {

        }

        public Vehicle(string type, string fuelType, string fuelStatus, string bodyType, string manufacturer, string registrationPlate, string model, string transmission, string discriminator)
        {
            this.type = type;
            this.fuelType = fuelType;
            this.fuelStatus = fuelStatus;
            this.bodyType = bodyType;
            this.manufacturer = manufacturer;
            this.registrationPlate = registrationPlate;
            this.model = model;
            this.transmission = transmission;
            this.discriminator = discriminator;
        }

        public void AddAVehicle()
        {
            Console.WriteLine("Vehicle Type:");
            type = Console.ReadLine();

            Console.WriteLine("Fuel Type:");
            fuelType = Console.ReadLine();

            fuelStatus = "fully fueled";

            Console.WriteLine("Body Type (If Motorbike please leave empty):");
            var bt = Console.ReadLine();
            if (bt == "" || bt == null)
            {
                bodyType = "";
            }
            else
            {
                bodyType = bt;
            }

            Console.WriteLine("Manufacturer:");
            manufacturer = Console.ReadLine();

            Console.WriteLine("Registration:");
            registrationPlate = Console.ReadLine();

            Console.WriteLine("Model:");
            model = Console.ReadLine();

            Console.WriteLine("Transmission: ");
            transmission = Console.ReadLine();
            Vehicle v = new Vehicle(type, fuelType, fuelStatus, bodyType, manufacturer, registrationPlate, model, transmission, "Vehicle");
            DBScheme1.Vehicles.Add(v);
            DBScheme1.SaveChanges();

        }

        public void removeVehicle()
        {
            var info = DBScheme1.Vehicles.ToList();
            foreach (var a in info)
            {
                Console.WriteLine("\n\nID: " + a.ID + "\nType: " + a.type + "\nFuel Type: " + a.fuelType + "\nFuel Status: " + a.fuelStatus + "\nBody Type: " + a.bodyType + "\nManufacturer: " + a.manufacturer + "\nRegistration Plate: " + a.registrationPlate + "\nModel: " + a.model + "\nTransmission: " + a.transmission);
            }
            Console.WriteLine("please enter ID of the vehicle you wish to remove: ");
            var y = Console.ReadLine();
            int z;
            if (int.TryParse(y, out z))
            {
                var x = DBScheme1.Vehicles.Find(z);
                DBScheme1.Vehicles.Remove(x);
                DBScheme1.SaveChanges();
            }
            else
            {
                Console.WriteLine("ERROR");
                Thread.Sleep(1000);
            }
        }

        public void printVehicles()
        {
            var info = DBScheme1.Vehicles.ToList();
            foreach (var a in info)
            {
                Console.WriteLine("\n\nID: " + a.ID + "\nType: " + a.type + "\nFuel Type: " + a.fuelType + "\nFuel Status: " + a.fuelStatus + "\nBody Type: " + a.bodyType + "\nManufacturer: " + a.manufacturer + "\nRegistration Plate: " + a.registrationPlate + "\nModel: " + a.model + "\nTransmission: " + a.transmission);
            }
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
