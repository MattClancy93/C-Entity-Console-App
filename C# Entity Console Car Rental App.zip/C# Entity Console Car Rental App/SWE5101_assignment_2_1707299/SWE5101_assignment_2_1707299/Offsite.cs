﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading;

namespace SWE5101_assignment_2_1707299
{
    public class Offsite : Vehicle
    {
        
        public Offsite()
        {

        }

        DBScheme DBScheme1 = new DBScheme();


        public Offsite(Vehicle v, int offsite)
        {
            this.type = v.type;
            this.fuelType = v.fuelType;
            this.fuelStatus = v.fuelStatus;
            this.bodyType = v.bodyType;
            this.manufacturer = v.manufacturer;
            this.registrationPlate = v.registrationPlate;
            this.model = v.model;
            this.transmission = v.transmission;
            this.discriminator = "Rental";
            this.offsite = offsite;
        }


        public void addRepair()
        {
            var info = DBScheme1.Vehicles.ToList();
            foreach (var a in info)
            {
                if (a.offsite < 1)
                {
                    Console.WriteLine("\n\nID: " + a.ID + "\nType: " + a.type + "\nFuel Type: " + a.fuelType + "\nFuel Status: " + a.fuelStatus + "\nBody Type: " + a.bodyType + "\nManufacturer: " + a.manufacturer + "\nRegistration Plate: " + a.registrationPlate + "\nModel: " + a.model + "\nTransmission: " + a.transmission);
                }
            }
            Console.WriteLine("please enter ID of vehicle you wish to repair: ");
            var y = Console.ReadLine();
            int z;
            if (int.TryParse(y, out z))
            {
                var x = DBScheme1.Vehicles.Find(z);
                Offsite o = new Offsite(x, 1);
                DBScheme1.Vehicles.Remove(x);
                DBScheme1.Vehicles.Add(o);
                DBScheme1.SaveChanges();
            }
            else
            {
                Console.WriteLine("ERROR");
                Thread.Sleep(1000);
            }

        }

        public void addRefuel()
        {

            var info = DBScheme1.Vehicles.ToList();
            foreach (var a in info)
            {
                if (a.offsite < 1)
                {
                    Console.WriteLine("\n\nID: " + a.ID + "\nType: " + a.type + "\nFuel Type: " + a.fuelType + "\nFuel Status: " + a.fuelStatus + "\nBody Type: " + a.bodyType + "\nManufacturer: " + a.manufacturer + "\nRegistration Plate: " + a.registrationPlate + "\nModel: " + a.model + "\nTransmission: " + a.transmission);
                }
            }
            Console.WriteLine("please enter ID of vehicle you wish to refuel: ");
            var y = Console.ReadLine();
            int z;
            if (int.TryParse(y, out z))
            {
                var x = DBScheme1.Vehicles.Find(z);
                Offsite o = new Offsite(x, 1);
                DBScheme1.Vehicles.Remove(x);
                DBScheme1.Vehicles.Add(o);
                DBScheme1.SaveChanges();
            }
            else
            {
                Console.WriteLine("ERROR");
                Thread.Sleep(1000);
            }
        }

        public void returnVehicle()
        {
            var info = DBScheme1.Vehicles.ToList();
            foreach (var a in info)
            {
                if (a.offsite == 1)
                {
                    Console.WriteLine("\n\nID: " + a.ID + "\nType: " + a.type + "\nFuel Type: " + a.fuelType + "\nFuel Status: " + a.fuelStatus + "\nBody Type: " + a.bodyType + "\nManufacturer: " + a.manufacturer + "\nRegistration Plate: " + a.registrationPlate + "\nModel: " + a.model + "\nTransmission: " + a.transmission);
                }
            }
            Console.WriteLine("please enter ID of vehicle you wish to return: ");
            var y = Console.ReadLine();
            int z;
            if (int.TryParse(y, out z))
            {
                var x = DBScheme1.Vehicles.Find(z);
                Offsite o = new Offsite(x, 0);
                DBScheme1.Vehicles.Remove(x);
                DBScheme1.Vehicles.Add(o);
                DBScheme1.SaveChanges();
            }
            else
            {
                Console.WriteLine("ERROR");
                Thread.Sleep(1000);
            }
        }
    }
}
