﻿using System.Data.Entity;

namespace SWE5101_assignment_2_1707299
{
    class DBScheme : DbContext
    {
        public DBScheme() : base(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Assignment\Desktop\SWE5101_1707299_A2_Matt_Clancy\SWE5101_assignment_2_1707299\SWE5101_assignment_2_1707299\ADORentalDatabase.mdf;Integrated Security=True;Connect Timeout=30") { }

        public DbSet<Vehicle> Vehicles { get; set; }
        public DbSet<Customer> Customers { get; set; }
    }
}
